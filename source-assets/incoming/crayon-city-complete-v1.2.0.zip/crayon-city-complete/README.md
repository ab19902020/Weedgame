# Crayon City Complete

This download contains every model in the free Crayon City collection.

- `city-architecture/` contains ten buildings.
- `city-trees/` contains seven trees.
- `city-props/` contains forty-four street and park props.
- Each collection includes textured and flat GLBs, a manifest, collision notes, and its license.
